let miMain = document.querySelector("main");
let miH2 = document.querySelector("h2");
let miA = document.querySelector("a");
let miP = document.querySelectorAll("p");
let miBody = document.querySelector("body");

let usuario = prompt ("Pone tu nombre GATO");
if(usuario!=null){
    miH2.innerText += usuario;
}else{
    miH2.innerText += "invitado";
}
miH2.style.textTransform = "uppercase";
miA.style.color = "#E51B3E";

let confirmacion = confirm("Desea poner fondo de pantalla?")
if(confirmacion)
{
miBody.classList.add("fondo");
}

for(let i=0;i<miP.length;i++){
    if(i%2==0){
        miP[i].classList.add("destacadoPar");
    }else{
        miP[i].classList.add("destacadoImpar");
    }
}

miMain.style.display = "block";

