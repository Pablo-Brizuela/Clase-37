let miH1 = document.querySelector("h1");
let miSection = document.querySelector("section");
let miArticle = document.querySelector("article");

miH1.innerText +="AGREGAR PELICULAS";
miH1.classList.add("titulo");
miArticle.classList.add("fondoTransparente");
miSection .classList.add("fondoCRUD");