let miH1 = document.querySelectorAll("h1");
let miBody = document.querySelector("body");

let oscuro = prompt ("Oscurito papi?");
if(oscuro!=null){
    miBody.style.backgroundColor = "#7f7f7f";
    miBody.classList.add("fondoMoviesList");
}

miH1.innerText +="LISTADO DE PELÍCULAS";
miH1.style.color = "white";
miH1.style.backgroundColor = "teal";
miH1.style.padding = "20px";
